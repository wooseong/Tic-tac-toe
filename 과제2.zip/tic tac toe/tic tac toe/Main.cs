﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Example
{
    public static void Main()
    {
        Menu_list menu;
        menu = new Menu_list();
        menu.show_MENU();
    }
}