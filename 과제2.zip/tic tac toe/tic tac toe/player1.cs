﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class player1
{
    public static string player_name;

    public static void player1_name()
    {
        Console.Write("\n  player1 : ");
        player_name = Console.ReadLine();
    }
}
