﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class player2
{
    public static string player_name;

    public static void player2_name()
    {
        Console.Write("\n  player2 : ");
        player_name = Console.ReadLine();
    }
}
